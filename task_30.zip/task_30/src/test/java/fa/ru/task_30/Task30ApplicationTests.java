package fa.ru.task_30;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task30ApplicationTests {

	@Test
	void contextLoads() {
	}

}
